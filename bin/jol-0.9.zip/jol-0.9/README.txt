Source: http://central.maven.org/maven2/org/openjdk/jol/
